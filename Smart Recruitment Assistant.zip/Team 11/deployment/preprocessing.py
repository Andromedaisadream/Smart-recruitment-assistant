"""
Shared preprocessing helpers. This MUST live in its own importable module
(not inside train_and_save_model.py's __main__ block) so that joblib can
pickle/unpickle the function reference correctly when the model is loaded
from a different script (app.py).
"""

import numpy as np
import pandas as pd


def clean_experience(series: pd.Series) -> pd.Series:
    s = series.astype(str).replace({"nan": np.nan})
    s = s.replace({">20": "21", "<1": "0"})
    s = pd.to_numeric(s, errors="coerce").fillna(0)
    return s.astype(int)


def clean_last_new_job(series: pd.Series) -> pd.Series:
    s = series.astype(str).replace({"nan": np.nan})
    s = s.replace({">4": "5", "never": "0"})
    s = pd.to_numeric(s, errors="coerce").fillna(0)
    return s.astype(int)


def ordinal_transform(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["experience"] = clean_experience(out["experience"])
    out["last_new_job"] = clean_last_new_job(out["last_new_job"])
    return out
