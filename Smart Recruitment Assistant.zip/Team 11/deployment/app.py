"""
Smart Recruitment Assistant -- Streamlit deployment app.

Loads the pre-trained pipeline (model.pkl) and exposes a simple form so a
recruiter can enter a candidate's raw details and get:
  - a prediction (likely to look for a job change or not)
  - the underlying probability
  - a short explanation

Run locally with:
    streamlit run app.py
"""

import json
from pathlib import Path
import joblib
import pandas as pd
import streamlit as st
st.set_page_config(page_title="Smart Recruitment Assistant", page_icon="🧑‍💼", layout="centered")
BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "model.pkl"
CITY_MAP_PATH = BASE_DIR / "city_cdi_map.json"


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_data
def load_city_map():
    with open(CITY_MAP_PATH) as f:
        return json.load(f)


model = load_model()
city_cdi_map = load_city_map()

st.title("🧑‍💼 Smart Recruitment Assistant")
st.caption(
    "Predicts whether a candidate is likely to be looking for a job change, "
    "based on their profile."
)

with st.form("candidate_form"):
    st.subheader("Candidate details")

    col1, col2 = st.columns(2)

    with col1:
        city = st.selectbox("City", sorted(city_cdi_map.keys()))
        gender = st.selectbox("Gender", ["Male", "Female", "Other"], index=0)
        relevent_experience = st.selectbox(
            "Relevant experience",
            ["Has relevent experience", "No relevent experience"],
        )
        enrolled_university = st.selectbox(
            "Enrolled in university?",
            ["no_enrollment", "Full time course", "Part time course"],
        )
        education_level = st.selectbox(
            "Education level",
            ["Graduate", "Masters", "Phd", "High School", "Primary School"],
        )

    with col2:
        major_discipline = st.selectbox(
            "Major discipline",
            ["STEM", "Business Degree", "Arts", "Humanities", "No Major", "Other"],
        )
        experience_options = ["<1"] + [str(i) for i in range(1, 21)] + [">20"]
        experience = st.selectbox("Years of experience", experience_options, index=6)
        company_size = st.selectbox(
            "Current company size",
            ["<10", "10/49", "50-99", "100-500", "500-999", "1000-4999", "5000-9999", "10000+"],
        )
        company_type = st.selectbox(
            "Current company type",
            ["Pvt Ltd", "Funded Startup", "Early Stage Startup", "Public Sector", "NGO", "Other"],
        )
        last_new_job_options = ["never", "1", "2", "3", "4", ">4"]
        last_new_job = st.selectbox("Years since last job change", last_new_job_options, index=1)

    training_hours = st.slider("Training hours completed", min_value=1, max_value=336, value=50)

    submitted = st.form_submit_button("Predict")

if submitted:
    city_development_index = city_cdi_map[city]

    input_df = pd.DataFrame(
        [
            {
                "city": city,
                "city_development_index": city_development_index,
                "gender": gender,
                "relevent_experience": relevent_experience,
                "enrolled_university": enrolled_university,
                "education_level": education_level,
                "major_discipline": major_discipline,
                "experience": experience,
                "company_size": company_size,
                "company_type": company_type,
                "last_new_job": last_new_job,
                "training_hours": training_hours,
            }
        ]
    )

    proba = model.predict_proba(input_df)[0, 1]
    prediction = "Likely looking for a change" if proba >= 0.5 else "Likely to stay"

    st.subheader("Result")
    st.metric("Probability of job-seeking", f"{proba:.1%}")

    if proba >= 0.7:
        st.error(f"🔴 {prediction} -- high priority for outreach")
    elif proba >= 0.5:
        st.warning(f"🟠 {prediction} -- worth a follow-up")
    else:
        st.success(f"🟢 {prediction}")

    with st.expander("City development index used"):
        st.write(
            f"City **{city}** has a development index of **{city_development_index}** "
            "(looked up automatically from historical data)."
        )
