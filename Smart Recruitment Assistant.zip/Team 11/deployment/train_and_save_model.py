"""
Trains a single scikit-learn Pipeline (preprocessing + Random Forest) on the
raw HR Analytics data and saves it to model.pkl.

Run this ONCE locally (or here) before deploying. The saved pipeline takes
RAW input (the same columns a recruiter would type in) and outputs a
prediction, so the Streamlit app doesn't need to duplicate any encoding logic.
"""

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder

from preprocessing import ordinal_transform  # shared module -- required for joblib pickling

RAW_CSV = "aug_train.csv"
MODEL_PATH = "model.pkl"

CATEGORICAL_COLS = [
    "city",
    "gender",
    "relevent_experience",
    "enrolled_university",
    "education_level",
    "major_discipline",
    "company_size",
    "company_type",
]
ORDINAL_COLS = ["experience", "last_new_job"]  # need custom numeric mapping
NUMERIC_COLS = ["city_development_index", "training_hours"]


def main() -> None:
    df = pd.read_csv(RAW_CSV)
    df = df.drop(columns=["enrollee_id"])

    X = df.drop(columns=["target"])
    y = df["target"]

    ordinal_pipeline = Pipeline(
        steps=[
            ("to_numeric", FunctionTransformer(ordinal_transform)),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    # ColumnTransformer applies ordinal cleanup then passes the two cleaned
    # columns straight through (they're already numeric after cleaning).
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", "passthrough", NUMERIC_COLS),
            ("cat", categorical_pipeline, CATEGORICAL_COLS),
            ("ord", ordinal_pipeline, ORDINAL_COLS),
        ],
        remainder="drop",
    )

    # The ordinal pipeline above returns a DataFrame with 2 columns already
    # numeric, but ColumnTransformer needs it to output an array of the same
    # width as the selected columns -- FunctionTransformer + passthrough on a
    # DataFrame slice does exactly that.
    # NOTE: n_estimators/max_depth are deliberately modest (vs. the notebook's
    # n_estimators=200 with unlimited depth) purely to keep the pickled file
    # small enough to push to GitHub / Streamlit Cloud without Git LFS.
    # This trades a small amount of accuracy for a ~50x smaller file.
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=14,
        min_samples_leaf=5,
        random_state=42,
        n_jobs=-1,
    )

    pipeline = Pipeline(steps=[("preprocessor", preprocessor), ("model", model)])

    pipeline.fit(X, y)

    joblib.dump(pipeline, MODEL_PATH)
    print(f"Saved trained pipeline to {MODEL_PATH}")

    # quick sanity check
    sample = X.iloc[[0]]
    proba = pipeline.predict_proba(sample)[0, 1]
    print(f"Sanity check prediction on row 0: probability of job-seeking = {proba:.3f}")


if __name__ == "__main__":
    main()
